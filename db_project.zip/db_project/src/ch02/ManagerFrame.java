package ch02;

import javax.swing.JFrame;

public class ManagerFrame extends JFrame {
	
	
	public ManagerFrame() {
		// TODO Auto-generated constructor stub
	}
	
	

}
